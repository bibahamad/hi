### Guides
Run `offlol.bat` as administrator to appear offline, with any arg to appear online.

```batch
$ offlol.bat
Please run as administrator.

admin $ offlol.bat
You will appear offline on League Client.

admin $ offlol.bat on
You will appear online on League Client.
```

### How it works?

The simplest way is block the chat server.<br>
Using `ping` to get the IP and block it via Windows Firewall.

Server list (in batch file)
```
BR     br.chat.si.riotgames.com
EUNE   eun1.chat.si.riotgames.com
EUW    euw1.chat.si.riotgames.com
JP     jp1.chat.si.riotgames.com
LAN    la1.chat.si.riotgames.com
LAS    la2.chat.si.riotgames.com
NA     na2.chat.si.riotgames.com
OCE    oc1.chat.si.riotgames.com
PH     ph1.chat.si.riotgames.com
RU     ru1.chat.si.riotgames.com
SG     sg1.chat.si.riotgames.com
TH     th1.chat.si.riotgames.com
TR     tr1.chat.si.riotgames.com
TW     tw1.chat.si.riotgames.com
VN     vn1.chat.si.riotgames.com
```